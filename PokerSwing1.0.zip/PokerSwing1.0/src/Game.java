import java.util.ArrayList;

public class Game {
    public Deck gameDeck = new Deck();
    public int pot;
    public ArrayList<Player> playerArrayList = new ArrayList<Player>();
    public Deck.Cards[] deal = new Deck.Cards[5];
}

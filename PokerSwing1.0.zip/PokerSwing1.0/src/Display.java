import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Display extends JFrame implements ActionListener {

    private ArrayList<JLabel> playerHandLabels = new ArrayList<JLabel>();
    private final ArrayList<JLabel> dealtCardLabels = new ArrayList<JLabel>();

    private final Deck deck = new Deck();
    Display() {
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}

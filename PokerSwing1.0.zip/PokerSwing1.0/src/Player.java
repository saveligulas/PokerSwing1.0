public class Player {
    public String NAME;
    public int stack;
    public int bet;
    public Deck.Cards[] hand = new Deck.Cards[2];
    public boolean isBigBlind;
    public boolean isSmallBlind;
    public boolean hasFolded;
    public ACTION actionTaken;
}
